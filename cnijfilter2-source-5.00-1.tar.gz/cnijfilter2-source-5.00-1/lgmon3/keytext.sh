#!/bin/sh
/usr/bin/perl keytext.pl <keytext/cnb_cnijlgmon2.res >po/keystr.h

